package api.player.model;

public interface IModelPlayerAPI extends IModelPlayer
{
	ModelPlayerAPI getModelPlayerAPI();

	api.player.model.ModelPlayer getModelPlayer();
}

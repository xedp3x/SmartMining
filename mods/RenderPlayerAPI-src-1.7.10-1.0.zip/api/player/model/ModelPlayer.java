package api.player.model;

public class ModelPlayer extends net.minecraft.client.model.ModelBiped
{
	public ModelPlayer(float paramFloat)
	{
		super(paramFloat);
	}
}